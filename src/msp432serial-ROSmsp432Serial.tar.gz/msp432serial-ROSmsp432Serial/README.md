# MSP432Serial

